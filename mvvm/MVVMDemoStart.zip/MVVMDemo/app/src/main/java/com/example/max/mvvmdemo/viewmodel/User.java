package com.example.max.mvvmdemo.viewmodel;

// TODO: add class User - model
