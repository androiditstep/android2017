package com.example.max.mvvmdemo.viewmodel;

// TODO: add LoginViewModel - ViewModel
