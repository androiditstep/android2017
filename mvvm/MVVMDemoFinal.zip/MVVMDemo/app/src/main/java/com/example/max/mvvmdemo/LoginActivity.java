package com.example.max.mvvmdemo;

import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Intent;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;

import com.example.max.mvvmdemo.databinding.ActivityLoginBinding;
import com.example.max.mvvmdemo.viewmodel.LoginViewModel;
import com.example.max.mvvmdemo.viewmodel.User;

/**
 * A login screen that offers login via email/password.
 */
public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // TODO: remove all UI references. use databinding instead
        ActivityLoginBinding dataBinding = DataBindingUtil.setContentView(this, R.layout.activity_login);
        LoginViewModel loginViewModel = ViewModelProviders.of(this).get(LoginViewModel.class);
        dataBinding.setViewModel(loginViewModel);
        dataBinding.setLifecycleOwner(this);

        loginViewModel.getUser().observe(this, new Observer<User>() {
            @Override
            public void onChanged(@Nullable User user) {
                startActivity(new Intent(LoginActivity.this, MainActivity.class));
            }
        });

        // TODO: move business logic to ViewModel
    }
}

