package com.example.max.mvvmdemo.viewmodel;

import android.arch.lifecycle.MutableLiveData;
import android.arch.lifecycle.ViewModel;
import android.os.AsyncTask;
import android.util.Patterns;
import android.view.View;

// TODO: add LoginViewModel - ViewModel
public class LoginViewModel extends ViewModel {

    private MutableLiveData<String> email = new MutableLiveData<>();
    private MutableLiveData<String> password = new MutableLiveData<>();

    private MutableLiveData<User> user = new MutableLiveData<>();

    private MutableLiveData<Integer> showProgress = new MutableLiveData<>();

    private MutableLiveData<Integer> showLoginForm = new MutableLiveData<>();

    public LoginViewModel() {
        showLoginForm.setValue(View.VISIBLE);
        showProgress.setValue(View.GONE);
    }

    public MutableLiveData<String> getEmail() {
        return email;
    }

    public void setEmail(MutableLiveData<String> email) {
        this.email = email;
    }

    public MutableLiveData<String> getPassword() {
        return password;
    }

    public void setPassword(MutableLiveData<String> password) {
        this.password = password;
    }

    public MutableLiveData<User> getUser() {
        return user;
    }

    public MutableLiveData<Integer> getShowProgress() {
        return showProgress;
    }

    public MutableLiveData<Integer> getShowLoginForm() {
        return showLoginForm;
    }

    public void onClick() {
        if(isEmailValid(email.getValue()) && isPasswordValid(password.getValue())) {
            showLoginForm.setValue(View.GONE);
            showProgress.setValue(View.VISIBLE);
            new LoginTask().execute(email.getValue(), password.getValue());
        }
    }

    private boolean isEmailValid(String email) {
        return Patterns.EMAIL_ADDRESS.matcher(email).matches();
    }

    private boolean isPasswordValid(String password) {
        return password.length() > 4;
    }

    class LoginTask extends AsyncTask<String, Void, User> {

        @Override
        protected User doInBackground(String... args) {
            String email = args[0];
            String password = args[1];

            // Wait for login...
            try {
                Thread.sleep(3000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            if( "admin@itstep.org".equals(email) && "12345".equals(password)) {
                return new User(email, password);
            } else {
                return null;
            }
        }

        @Override
        protected void onPostExecute(User user) {
            showProgress.setValue(View.GONE);
            if(user != null) {
                getUser().setValue(user);
            }
        }
    }


}
